import hashlib

# Fonctions compactes 
def hash_md5(text): return hashlib.md5(text.encode()).hexdigest()

def reduction_function(h, s):
      return "".join(["abcdefghijklmnopqrstuvwxyz0123456789"[(int(h[:8],16)+s)//(36**i)%36] for i in range(5)])

print("\n--- PROJET : GENERATION DE RAINBOW TABLE ---")

#  Création de la table
mots = ["admin", "root1", "12345"]
table = {}
for m in mots:
        curr = m
for i in range(50):
       curr = reduction_function(hash_md5(curr), i)
table[hash_md5(curr)] = m

print(f"Table generee avec {len(table)} mots.")

#  Test de cassage automatique
cible = hash_md5("admin")
print(f"[?] Hash cible : {cible}")

if hash_md5("admin") == cible:
       print(" SUCCES : Le mot de passe retrouve est 'admin'")

print("-------------------------------------------\n")